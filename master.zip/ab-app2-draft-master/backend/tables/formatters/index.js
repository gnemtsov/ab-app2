'use strict';

//IMPORTANT! Formatters' output is placed as HTML and must be safe!

module.exports.backendTestFormatter = (col, row) => `<b>${row.d_id * 2}</b>`;